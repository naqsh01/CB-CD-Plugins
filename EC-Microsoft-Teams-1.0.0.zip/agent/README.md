The content of this folder will be merged into <plugin>/agent folder. Place precompiled libraries into here.
